use ndarray::{Array2, Axis};
use ndarray::s;
use rand::{Rng, thread_rng, seq::SliceRandom};
use std::fs::File;
use csv::ReaderBuilder;
use std::collections::HashMap;

struct NeuralNetwork {
    weights_input_hidden: Array2<f64>,
    weights_hidden_output: Array2<f64>,
    learning_rate: f64,
}

impl NeuralNetwork {
    fn new(input_size: usize, hidden_size: usize, output_size: usize, learning_rate: f64) -> Self {
        let mut rng = rand::thread_rng();
        let weights_input_hidden = Array2::from_shape_fn((input_size, hidden_size), |_| rng.gen_range(-1.0..1.0));
        let weights_hidden_output = Array2::from_shape_fn((hidden_size, output_size), |_| rng.gen_range(-1.0..1.0));
        Self { weights_input_hidden, weights_hidden_output, learning_rate }
    }

    fn sigmoid(x: &Array2<f64>) -> Array2<f64> {
        x.mapv(|v| 1.0 / (1.0 + (-v).exp()))
    }

    fn sigmoid_derivative(x: &Array2<f64>) -> Array2<f64> {
        x * (1.0 - x)
    }

    fn train(&mut self, inputs: &Array2<f64>, targets: &Array2<f64>, epochs: usize) {
        for _ in 0..epochs {
            let hidden_inputs = inputs.dot(&self.weights_input_hidden);
            let hidden_outputs = Self::sigmoid(&hidden_inputs);
            let final_inputs = hidden_outputs.dot(&self.weights_hidden_output);
            let final_outputs = Self::sigmoid(&final_inputs);

            let output_errors = targets - &final_outputs;
            let output_grad = output_errors * Self::sigmoid_derivative(&final_outputs);

            let hidden_errors = output_grad.dot(&self.weights_hidden_output.t());
            let hidden_grad = hidden_errors * Self::sigmoid_derivative(&hidden_outputs);

            self.weights_hidden_output += &hidden_outputs.t().dot(&output_grad).mapv(|v| v * self.learning_rate);
            self.weights_input_hidden += &inputs.t().dot(&hidden_grad).mapv(|v| v * self.learning_rate);
        }
    }
}

fn one_hot_encode(labels: &Array2<f64>, num_classes: usize) -> Array2<f64> {
    let mut one_hot = Array2::<f64>::zeros((labels.shape()[0], num_classes));
    for (i, row) in labels.axis_iter(Axis(0)).enumerate() {
        let class = row[0] as usize;
        one_hot[[i, class]] = 1.0;
    }
    one_hot
}

fn load_dataset(filename: &str) -> (Array2<f64>, Array2<f64>, HashMap<String, usize>) {
    let file = File::open(filename).expect("Failed to open file");
    let mut rdr = ReaderBuilder::new().has_headers(true).from_reader(file);

    let mut records: Vec<(Vec<f64>, String)> = Vec::new();
    let mut label_set: HashMap<String, usize> = HashMap::new();
    let mut next_label = 0;

    for result in rdr.records() {
        if let Ok(record) = result {
            let temp = record[0].trim().parse::<f64>();
            let humid = record[1].trim().parse::<f64>();
            let moist = record[2].trim().parse::<f64>();

            if let (Ok(t), Ok(h), Ok(m)) = (temp, humid, moist) {
                let label = record[4].trim().to_string(); // Crop Type
                let label_index = *label_set.entry(label.clone()).or_insert_with(|| {
                    let id = next_label;
                    next_label += 1;
                    id
                });

                records.push((vec![t, h, m], label_index.to_string()));
            } else {
                eprintln!("Skipping invalid row: {:?}", record);
            }
        }
    }

    let mut rng = thread_rng();
    records.shuffle(&mut rng);

    let mut data = vec![];
    let mut targets = vec![];

    for (features, label_str) in records {
        let label = label_str.parse::<f64>().unwrap();
        data.push(features);
        targets.push(vec![label]);
    }

    let data_array = Array2::from_shape_vec(
        (data.len(), 3),
        data.into_iter().flatten().collect()
    ).expect("Failed to create data array");

    let target_array = Array2::from_shape_vec(
        (targets.len(), 1),
        targets.into_iter().flatten().collect()
    ).expect("Failed to create target array");

    (data_array, target_array, label_set)
}

fn main() {
    let (inputs, targets, label_map) = load_dataset("data_core.csv");

    let input_size = 3;
    let output_size = label_map.len();
    let hidden_size = 10;
    let learning_rate = 0.1;
    let epochs = 100;

    let targets_one_hot = one_hot_encode(&targets, output_size);

    let total_samples = inputs.shape()[0];
    let train_size = (total_samples as f64 * 0.8).round() as usize;

    let x_train = inputs.slice(s![..train_size, ..]).to_owned();
    let y_train = targets_one_hot.slice(s![..train_size, ..]).to_owned();
    let _y_train_raw = targets.slice(s![..train_size, ..]).to_owned();

    let x_test = inputs.slice(s![train_size.., ..]).to_owned();
    let y_test = targets.slice(s![train_size.., ..]).to_owned();

    let mut nn = NeuralNetwork::new(input_size, hidden_size, output_size, learning_rate);
    nn.train(&x_train, &y_train, epochs);

    let hidden_inputs = x_test.dot(&nn.weights_input_hidden);
    let hidden_outputs = NeuralNetwork::sigmoid(&hidden_inputs);
    let final_inputs = hidden_outputs.dot(&nn.weights_hidden_output);
    let final_outputs = NeuralNetwork::sigmoid(&final_inputs);

    let predictions: Vec<usize> = final_outputs
        .axis_iter(Axis(0))
        .map(|row| {
            row.iter()
                .enumerate()
                .max_by(|a, b| a.1.partial_cmp(b.1).unwrap())
                .map(|(idx, _)| idx)
                .unwrap_or(0)
        })
        .collect();

    let actuals: Vec<usize> = y_test.iter().map(|v| *v as usize).collect();

    let correct = predictions.iter().zip(actuals.iter()).filter(|(a, b)| a == b).count();
    let accuracy = correct as f64 / predictions.len() as f64 * 100.0;

    println!("Test Accuracy: {:.2}%", accuracy);

    let reverse_map: HashMap<usize, String> =
        label_map.iter().map(|(k, v)| (*v, k.clone())).collect();

    println!("\nSample predictions:");
    for (i, (pred, actual)) in predictions.iter().zip(actuals.iter()).take(10).enumerate() {
        let pred_label = reverse_map.get(pred).unwrap();
        let actual_label = reverse_map.get(actual).unwrap();
        println!("Sample {}: Predicted = {:<8} | Actual = {}", i + 1, pred_label, actual_label);
    }
}
