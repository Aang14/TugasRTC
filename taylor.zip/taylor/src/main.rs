use std::f64::consts::PI;
use std::io;

// Fungsi untuk menghitung faktorial
fn factorial(n: u32) -> f64 {
    if n == 0 {
        1.0
    } else {
        (1..=n).fold(1.0, |acc, x| acc * x as f64)
    }
}

// Fungsi untuk menghitung sinus menggunakan deret Taylor
fn taylor_sin(x: f64, terms: u32) -> f64 {
    let mut result = 0.0;
    for n in 0..terms {
        let exponent = 2 * n + 1;
        let term = (-1f64).powi(n as i32) * x.powi(exponent as i32) / factorial(exponent);
        result += term;
    }
    result
}

// Fungsi untuk menghitung cosinus menggunakan deret Taylor
fn taylor_cos(x: f64, terms: u32) -> f64 {
    let mut result = 0.0;
    for n in 0..terms {
        let exponent = 2 * n;
        let term = (-1f64).powi(n as i32) * x.powi(exponent as i32) / factorial(exponent);
        result += term;
    }
    result
}

// Fungsi untuk mengkonversi derajat ke radian
fn degrees_to_radians(degrees: f64) -> f64 {
    degrees * PI / 180.0
}

fn main() {
    println!("Kalkulator Sinus dan Cosinus menggunakan Deret Taylor");
    println!("-----------------------------------------------------");

    loop {
        println!("\nPilih input:");
        println!("1. Sudut dalam derajat");
        println!("2. Sudut dalam radian");
        println!("3. Keluar");
        println!("Masukkan pilihan (1/2/3):");

        let mut choice = String::new();
        io::stdin()
            .read_line(&mut choice)
            .expect("Gagal membaca input");

        let choice = choice.trim();
        if choice == "3" {
            println!("Terima kasih!");
            break;
        }

        let (angle, angle_rad) = if choice == "1" {
            println!("Masukkan sudut dalam derajat:");
            let mut degrees = String::new();
            io::stdin()
                .read_line(&mut degrees)
                .expect("Gagal membaca input");
            let degrees: f64 = degrees.trim().parse().expect("Harap masukkan angka");
            (degrees.to_string() + "°", degrees_to_radians(degrees))
        } else if choice == "2" {
            println!("Masukkan sudut dalam radian:");
            let mut radians = String::new();
            io::stdin()
                .read_line(&mut radians)
                .expect("Gagal membaca input");
            let radians: f64 = radians.trim().parse().expect("Harap masukkan angka");
            (radians.to_string() + " rad", radians)
        } else {
            println!("Pilihan tidak valid!");
            continue;
        };

        println!("Masukkan jumlah iterasi (semakin besar semakin akurat):");
        let mut iterations = String::new();
        io::stdin()
            .read_line(&mut iterations)
            .expect("Gagal membaca input");
        let iterations: u32 = iterations.trim().parse().expect("Harap masukkan bilangan bulat positif");

        // Hitung sin dan cos
        let sin_result = taylor_sin(angle_rad, iterations);
        let cos_result = taylor_cos(angle_rad, iterations);

        // Bandingkan dengan fungsi standar
        let std_sin = angle_rad.sin();
        let std_cos = angle_rad.cos();

        println!("\nHasil perhitungan untuk sudut {}:", angle);
        println!("Sinus (Taylor): {:.15}", sin_result);
        println!("Sinus (Standar): {:.15}", std_sin);
        println!("Selisih: {:.15e}", (sin_result - std_sin).abs());
        println!("\nCosinus (Taylor): {:.15}", cos_result);
        println!("Cosinus (Standar): {:.15}", std_cos);
        println!("Selisih: {:.15e}", (cos_result - std_cos).abs());
    }
}