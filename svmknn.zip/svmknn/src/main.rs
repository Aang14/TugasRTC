use linfa::prelude::*;
use linfa_svm::Svm;
use linfa_logistic::MultiLogisticRegression;
use ndarray::{s, Array1, Array2, Axis};
use plotters::prelude::*;
use csv::ReaderBuilder;
use plotters::style::full_palette::{BROWN, PURPLE};
use std::collections::HashMap;
use std::fs;
use rand::seq::SliceRandom;
use rand::thread_rng;
use std::error::Error;

// =================== DATA LOADER ===================
fn load_data(path: &str) -> Result<(Array2<f64>, Array1<usize>, HashMap<usize, String>), Box<dyn Error>> {
    let mut rdr = ReaderBuilder::new().has_headers(true).from_path(path)?;

    let mut records: Vec<_> = rdr.records().collect::<Result<_, _>>()?;
    records.shuffle(&mut thread_rng());

    let mut features = Vec::new();
    let mut labels = Vec::new();
    let mut label_map = HashMap::new();
    let mut label_reverse_map = HashMap::new();
    let mut label_counter = 0;

    for record in &records {
        let feat: Vec<f64> = vec![
            record[0].trim().parse::<f64>().unwrap_or(0.0), // Temperature
            record[1].trim().parse::<f64>().unwrap_or(0.0), // Humidity
            record[2].trim().parse::<f64>().unwrap_or(0.0), // Moisture
            record[5].trim().parse::<f64>().unwrap_or(0.0), // Nitrogen
            record[6].trim().parse::<f64>().unwrap_or(0.0), // Potassium
            record[7].trim().parse::<f64>().unwrap_or(0.0), // Phosphorous
        ];
        features.push(feat);

        let label_str = record[4].trim(); // Crop Type
        let label = *label_map.entry(label_str.to_string()).or_insert_with(|| {
            let id = label_counter;
            label_reverse_map.insert(id, label_str.to_string());
            label_counter += 1;
            id
        });
        labels.push(label);
    }

    Ok((
        Array2::from_shape_vec((features.len(), 6), features.concat())?,
        Array1::from_vec(labels),
        label_reverse_map,
    ))
}

// =================== EUCLIDEAN DISTANCE ===================
fn euclidean_distance(a: &Array1<f64>, b: &Array1<f64>) -> f64 {
    a.iter().zip(b.iter()).map(|(x, y)| (x - y).powi(2)).sum::<f64>().sqrt()
}

// =================== KNN ===================
fn predict_knn(
    train: &Array2<f64>,
    train_labels: &Array1<usize>,
    test: &Array2<f64>,
    k: usize,
) -> Array1<usize> {
    let mut predictions = Array1::zeros(test.nrows());

    for (i, test_sample) in test.axis_iter(Axis(0)).enumerate() {
        let mut distances: Vec<_> = train
            .axis_iter(Axis(0))
            .enumerate()
            .map(|(j, train_sample)| {
                let dist = euclidean_distance(&train_sample.to_owned(), &test_sample.to_owned());
                (j, dist)
            })
            .collect();

        distances.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());

        let mut counts = HashMap::new();
        for &(idx, _) in distances.iter().take(k) {
            let label = train_labels[idx];
            *counts.entry(label).or_insert(0) += 1;
        }

        let predicted_label = counts.into_iter().max_by_key(|&(_, c)| c).unwrap().0;
        predictions[i] = predicted_label;
    }

    predictions
}

// =================== SVM ===================
fn train_svm(train_x: Array2<f64>, train_y: Array1<f64>, test_x: Array2<f64>) -> Array1<f64> {
    let dataset = Dataset::new(train_x, train_y);

    let model = Svm::params()
        .gaussian_kernel(100.0)
        .fit(&dataset)
        .expect("Gagal melatih SVM");

    model.predict(&test_x)
}

// =================== AKURASI ===================
fn accuracy(pred: &Array1<f64>, target: &Array1<usize>) -> f64 {
    pred.iter().zip(target.iter()).filter(|(p, t)| **p as usize == **t).count() as f64 / pred.len() as f64
}

fn plot_predictions(
    filename: &str,
    data: &Array2<f64>,
    labels: &Array1<usize>,
    label_map: &HashMap<usize, String>,
    title: &str,
) -> Result<(), Box<dyn Error>> {
    let root = BitMapBackend::new(filename, (800, 600)).into_drawing_area();
    root.fill(&WHITE)?;

    let x_range = data.column(0).iter().cloned().fold(f64::INFINITY, f64::min)
        ..data.column(0).iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    let y_range = data.column(1).iter().cloned().fold(f64::INFINITY, f64::min)
        ..data.column(1).iter().cloned().fold(f64::NEG_INFINITY, f64::max);

    let mut chart = ChartBuilder::on(&root)
        .caption(title, ("sans-serif", 30).into_font())
        .margin(10)
        .x_label_area_size(40)
        .y_label_area_size(40)
        .build_cartesian_2d(x_range.clone(), y_range.clone())?;

    chart.configure_mesh().draw()?;

    let colors = &[
        &RED, &BLUE, &GREEN, &CYAN, &MAGENTA, &YELLOW, &BLACK, &PURPLE, &BROWN,
    ];

    for (i, point) in data.outer_iter().enumerate() {
        let label = labels[i];
        let color = colors[label % colors.len()];
        chart.draw_series(PointSeries::of_element(
            vec![(point[0], point[1])],
            5,
            ShapeStyle::from(color).filled(),
            &|c, s, st| {
                return EmptyElement::at(c) + Circle::new((0, 0), s, st);
            },
        ))?;
    }

    Ok(())
}


// =================== MAIN ===================
fn main() -> Result<(), Box<dyn Error>> {
    let (features, labels_usize, label_map) = load_data("data_core.csv")?;

    // Cek distribusi label
    let mut label_count = HashMap::new();
    for label in labels_usize.iter() {
        *label_count.entry(label).or_insert(0) += 1;
    }

    println!("📊 Distribusi label tanaman:");
    for (label, count) in label_count.iter() {
        println!(" - {}: {}", label_map[label], count);
    }

    let split_idx = (features.nrows() as f64 * 0.8) as usize;
    let (train_x, test_x) = features.view().split_at(Axis(0), split_idx);
    let (train_y_usize, test_y_usize) = labels_usize.view().split_at(Axis(0), split_idx);
    let train_y_f64 = train_y_usize.to_owned().mapv(|x| x as f64);

    // Prediksi SVM
    let svm_preds = train_svm(train_x.to_owned(), train_y_f64.clone(), test_x.to_owned());
    let svm_acc = accuracy(&svm_preds, &test_y_usize.to_owned());
    println!("🎯 Akurasi SVM: {:.2}%", svm_acc * 100.0);

    // Prediksi KNN
    let knn_preds = predict_knn(&train_x.to_owned(), &train_y_usize.to_owned(), &test_x.to_owned(), 3);
    let knn_acc = knn_preds
        .iter()
        .zip(test_y_usize.iter())
        .filter(|(p, t)| *p == *t)
        .count() as f64 / knn_preds.len() as f64;
    println!("🎯 Akurasi KNN: {:.2}%", knn_acc * 100.0);

    // Visualisasi prediksi SVM dan KNN
    let test_x_f64 = test_x.to_owned();

    let svm_labels_usize = svm_preds.mapv(|x| x as usize);
    let knn_labels_usize = knn_preds;

    plot_predictions(
        "svm_predictions.png",
        &test_x_f64.slice(s![.., 0..2]).to_owned(),
        &svm_labels_usize,
        &label_map,
        "SVM Predictions (2D)",
    )?;

    plot_predictions(
        "knn_predictions.png",
        &test_x_f64.slice(s![.., 0..2]).to_owned(),
        &knn_labels_usize,
        &label_map,
        "KNN Predictions (2D)",
    )?;

    // Cetak prediksi vs label
    println!("\n🔍 20 Prediksi SVM-KNN vs Aktual:");
    for (i, (pred, actual)) in svm_preds.iter().zip(test_y_usize.iter()).take(20).enumerate() {
        println!(
            "Data {:2}: Prediksi = {:<12} | Aktual = {:<12}",
            i + 1,
            label_map[&(*pred as usize)],
            label_map[actual]
        );
    }
    let knn_preds = predict_knn(&train_x.to_owned(), &train_y_usize.to_owned(), &test_x.to_owned(), 3);
    let knn_acc = knn_preds
        .iter()
        .zip(test_y_usize.iter())
        .filter(|(p, t)| *p == *t)
        .count() as f64 / knn_preds.len() as f64;

    Ok(())
}

