use std::f64::consts::PI;

struct LookupTable {
    sine_values: Vec<f64>,
    resolution: usize,
}

impl LookupTable {
    fn new(resolution: usize) -> Self {
        let mut sine_values = Vec::with_capacity(resolution);
        let step = 2.0 * PI / (resolution as f64);
        
        for i in 0..resolution {
            sine_values.push((i as f64 * step).sin());
        }
        
        LookupTable {
            sine_values,
            resolution,
        }
    }
    
    fn sine(&self, angle: f64) -> f64 {
        // Normalize angle to [0, 2π]
        let normalized_angle = angle.rem_euclid(2.0 * PI);
        let index = (normalized_angle / (2.0 * PI) * self.resolution as f64).round() as usize % self.resolution;
        self.sine_values[index]
    }
    
    fn cosine(&self, angle: f64) -> f64 {
        // cos(x) = sin(x + π/2)
        self.sine(angle + PI / 2.0)
    }
}

fn main() {
    // Buat lookup table dengan 360 titik (1 derajat per step)
    let lookup = LookupTable::new(360);
    
    // Contoh penggunaan
    let angles = [0.0, PI/6.0, PI/4.0, PI/3.0, PI/2.0, PI, 3.0*PI/2.0, 2.0*PI];
    
    println!("{:<10} | {:<15} | {:<15} | {:<15} | {:<15}", 
             "Angle", "LUT Sine", "Actual Sine", "LUT Cosine", "Actual Cosine");
    println!("{:-<70}", "");
    
    for &angle in &angles {
        let lut_sin = lookup.sine(angle);
        let actual_sin = angle.sin();
        let lut_cos = lookup.cosine(angle);
        let actual_cos = angle.cos();
        
        println!("{:<10.4} | {:<15.8} | {:<15.8} | {:<15.8} | {:<15.8}", 
                 angle, lut_sin, actual_sin, lut_cos, actual_cos);
    }
    
    // Contoh error maksimal
    let test_points = 1000;
    let mut max_sin_error = 0.0;
    let mut max_cos_error = 0.0;
    
    for i in 0..test_points {
        let angle = 4.0 * PI * (i as f64) / (test_points as f64);
        let sin_error = (lookup.sine(angle) - angle.sin()).abs();
        let cos_error = (lookup.cosine(angle) - angle.cos()).abs();
        
        if sin_error > max_sin_error {
            max_sin_error = sin_error;
        }
        if cos_error > max_cos_error {
            max_cos_error = cos_error;
        }
    }
    
    println!("\nMax sine error: {:.8}", max_sin_error);
    println!("Max cosine error: {:.8}", max_cos_error);
}